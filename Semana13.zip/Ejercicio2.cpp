#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

struct Empleado {
	int horas_semanales; // 20 a 50
	char oficina; // C, S o L
	int min_tardanza; // 0 a 180
};

void genera_arreglo(Empleado* empleados, const int total_empleados)
{
	Random r;
	for (int i = 0; i < total_empleados; ++i) {
		empleados[i].horas_semanales = r.Next(20, 51);
		empleados[i].min_tardanza = r.Next(0, 181);

		int oficina_aleatoria = r.Next(1, 4);
		if (oficina_aleatoria == 1) {
			empleados[i].oficina = 'C';
		}
		else if (oficina_aleatoria == 2) {
			empleados[i].oficina = 'S';
		}
		else {
			empleados[i].oficina = 'L';
		}
		//empleados[i].oficina = (oficina_aleatoria == 1) ? 'C' : (oficina_aleatoria == 2) ? 'S' : 'L';
	}
}

void imprime_arreglo(Empleado* empleados, const int total_empleados)
{
	cout << "Id\tHoras\tOficina\tMinutos\n";
	for (int i = 0; i < total_empleados; ++i) {
		cout << i << '\t' << empleados[i].horas_semanales
			<< '\t' << empleados[i].oficina
			<< '\t' << empleados[i].min_tardanza << '\n';
	}
}

void empleados_mas_trabajadores(Empleado* empleados, const int total_empleados)
{
	int mayor_horas = empleados[0].horas_semanales;
	for (int i = 1; i < total_empleados; ++i) {
		if (empleados[i].horas_semanales > mayor_horas) {
			mayor_horas = empleados[i].horas_semanales;
		}
	}

	cout << "Empleados con mayor de horas:\n";
	for (int i = 0; i < total_empleados; ++i) {
		if (empleados[i].horas_semanales == mayor_horas) {
			cout << "Id: " << i << '\n';
		}
	}
}

void promedio_de_tardanzas_por_oficina(Empleado* empleados, const int total_empleados)
{
	int cantidad_oficinas = 3;
	int total_minutos = 0;
	// indice: 0 = oficina: C
	// indice: 1 = oficina: S
	// indice: 1 = oficina: L
	float* tardanzas_por_oficina = new float[cantidad_oficinas];
	for (int i = 0; i < cantidad_oficinas; ++i) {
		tardanzas_por_oficina[i] = 0;
	}

	for (int i = 0; i < total_empleados; ++i) {
		total_minutos += empleados[i].min_tardanza;
		switch (empleados[i].oficina)
		{
		case 'C':
			tardanzas_por_oficina[0] += empleados[i].min_tardanza;
			break;
		case 'S':
			tardanzas_por_oficina[1] += empleados[i].min_tardanza;
			break;
		case 'L':
			tardanzas_por_oficina[2] += empleados[i].min_tardanza;
			break;
		}
	}

	cout << "Promedio de minutos de tardanzas por oficina\n";
	cout << "Oficina C: " << tardanzas_por_oficina[0] / total_minutos << '\n';
	cout << "Oficina S: " << tardanzas_por_oficina[1] / total_minutos << '\n';
	cout << "Oficina L: " << tardanzas_por_oficina[2] / total_minutos << '\n';
}

void empleados_puntuales(Empleado* empleados, const int total_empleados)
{
	for (int i = 0; i < total_empleados; ++i)
	{
		if (empleados[i].min_tardanza == 0) {
			cout << "EMPLEADO PUNTUAL\n";
			cout << "Id: " << i << '\n';
			cout << "Horas trabajadas: " << empleados[i].horas_semanales << '\n';
			cout << "Oficina: " << empleados[i].oficina << '\n';
		}
	}
}

void ordena_arreglo(Empleado* empleados, const int total_empleado)
{
	for (int i = 0; i < total_empleado - 1; ++i) {
		for (int j = 0; j < total_empleado - 1 - i; ++j) {
			if (empleados[j + 1].oficina <= empleados[j].oficina) {
				Empleado copia_empleado = empleados[j];
				empleados[j] = empleados[j + 1];
				empleados[j + 1] = copia_empleado;
			}
		}
	}
}

int main()
{
	const int total_empleados = 20;
	Empleado* empleados = new Empleado[total_empleados];
	genera_arreglo(empleados, total_empleados);
	imprime_arreglo(empleados, total_empleados);
	empleados_mas_trabajadores(empleados, total_empleados);
	promedio_de_tardanzas_por_oficina(empleados, total_empleados);
	empleados_puntuales(empleados, total_empleados);
	ordena_arreglo(empleados, total_empleados);
	imprime_arreglo(empleados, total_empleados);
	_getch();
	return 0;
}
