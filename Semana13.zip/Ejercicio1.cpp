#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void generar_mensaje(char* mensaje, int longitud_mensaje)
{
	Random r;
	for (int i = 0; i < longitud_mensaje; ++i) {
		mensaje[i] = r.Next('A', 'Z');
	}
}

void imprimir_mensaje(char* mensaje, int longitud_mensaje)
{
	for (int i = 0; i < longitud_mensaje; ++i) {
		cout << mensaje[i] << ' ';
	}
	cout << '\n';
}

bool existen_caracteres_inicio_final(char* mensaje, int longitud_mensaje)
{
	// si hay una S al inicio y una W al final, entonces retornar verdadero
	if (mensaje[0] == 'S' && mensaje[longitud_mensaje - 1] == 'W') {
		return true;
	}
	else {
		return false;
	}
}

bool existe_mensaje_alterno(char* mensaje, int longitud_mensaje)
{
	int longitud_palabra_buscar = 3;
	char* palabra_buscar = new char[longitud_palabra_buscar] { 'S', 'I', 'S' };
	int sis_indice = 0;
	for (int i = 0; i < longitud_mensaje; ++i) {
		if (mensaje[i] == palabra_buscar[sis_indice]) {
			++sis_indice;
		}
	}
	if (sis_indice == longitud_palabra_buscar) {
		return true;
	}
	else {
		return false;
	}
}

int main()
{
	while (true)
	{
		int longitud_mensaje;
		do
		{
			cout << "Ingrese longitud mensaje: ";
			cin >> longitud_mensaje;
		} while (!(longitud_mensaje > 0));

		char* mensaje = new char[longitud_mensaje];
		generar_mensaje(mensaje, longitud_mensaje);
		imprimir_mensaje(mensaje, longitud_mensaje);
		if (existen_caracteres_inicio_final(mensaje, longitud_mensaje)) {
			cout << "Es un estudiante de Software\n";
		}
		else if (existe_mensaje_alterno(mensaje, longitud_mensaje)) {
			cout << "Es un estudiante de Sistemas\n";
		}
		else {
			cout << "No hay mensaje oculto\n";
		}
		_getch();
	}

	return 0;
}