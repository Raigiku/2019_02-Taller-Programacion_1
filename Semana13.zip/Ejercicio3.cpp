#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void agregar_digito(int digito, int*& numero_largo, int cantidad_digitos)
{
	if (cantidad_digitos != 1) {
		int* copia = numero_largo;
		numero_largo = new int[cantidad_digitos];
		for (int i = 0; i < cantidad_digitos - 1; ++i) {
			numero_largo[i] = copia[i];
		}
		numero_largo[cantidad_digitos - 1] = digito;
		delete[] copia;
	}
	else {
		numero_largo = new int[cantidad_digitos] {digito};
	}
}

void imprimir_numero_largo(int* numero_largo, int cantidad_digitos)
{
	for (int i = 0; i < cantidad_digitos; ++i) {
		cout << numero_largo[i] << ' ';
	}
	cout << '\n';
}

int main()
{
	int cantidad_digitos = 0;
	int* numero_largo = new int[cantidad_digitos];

	bool detener = false;
	int digito;
	do
	{
		cout << "Ingrese digito: ";
		cin >> digito;
		switch (digito)
		{
		case 50:
			detener = true;
			break;
		default:
			++cantidad_digitos;
			agregar_digito(digito, numero_largo, cantidad_digitos);
			imprimir_numero_largo(numero_largo, cantidad_digitos);
			break;
		}
	} while (!(detener));
	return 0;
}