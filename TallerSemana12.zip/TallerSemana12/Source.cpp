#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

const int max_filas = 20;
const int max_columnas = 20;

struct Ficha {
	int x;
	int y;
	int direccion_x; // 1: se mueve a la derecha; -1: se mueve a la izquierda
	int direccion_y; // 1: se mueve hacia abajo; -1: se mueve hacia arriba
};

void dibujar_escenario(int**& matriz)
{
	for (int fila = 0; fila < max_filas; ++fila) {
		for (int columna = 0; columna < max_columnas; ++columna) {

			switch (matriz[fila][columna])
			{
			case 1:
				Console::BackgroundColor = ConsoleColor::White;
				break;
			case 0:
				Console::BackgroundColor = ConsoleColor::Black;
				break;
			}

			Console::SetCursorPosition(columna, fila);
			cout << " ";
		}
	}

	Console::ResetColor();
}

void genera_muestra_matriz(int**& matriz)
{
	int mapa[max_filas][max_columnas] = {
		{ 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },
	};

	matriz = new int*[max_filas];
	for (int fila = 0; fila < max_filas; ++fila) {
		matriz[fila] = new int[max_columnas];
		for (int columna = 0; columna < max_columnas; ++columna) {
			matriz[fila][columna] = mapa[fila][columna];
		}
	}

	dibujar_escenario(matriz);
}

void dibujar_jugador(Ficha& jugador)
{
	Console::BackgroundColor = ConsoleColor::Green;

	Console::SetCursorPosition(jugador.x + 1, jugador.y);
	cout << " ";
	Console::SetCursorPosition(jugador.x + 2, jugador.y);
	cout << " ";
	Console::SetCursorPosition(jugador.x, jugador.y + 1);
	cout << " ";
	Console::SetCursorPosition(jugador.x + 1, jugador.y + 1);
	cout << " ";
	Console::SetCursorPosition(jugador.x + 2, jugador.y + 1);
	cout << " ";

	Console::ResetColor();
}

void borrar_jugador(Ficha& jugador)
{
	Console::SetCursorPosition(jugador.x + 1, jugador.y);
	cout << " ";
	Console::SetCursorPosition(jugador.x + 2, jugador.y);
	cout << " ";
	Console::SetCursorPosition(jugador.x, jugador.y + 1);
	cout << " ";
	Console::SetCursorPosition(jugador.x + 1, jugador.y + 1);
	cout << " ";
	Console::SetCursorPosition(jugador.x + 2, jugador.y + 1);
	cout << " ";
}

bool colisiona(int**& matriz, Ficha& jugador)
{
	// PARA MOVIMIENTO HORIZONTAL
	// colision_1: para la celda (x-1;y+1)
	bool colision_1 = matriz[jugador.y + 1][jugador.x + jugador.direccion_x] == 1;
	// colision_2: para la celda (x+3;y+1)
	bool colision_2 = matriz[jugador.y + 1][jugador.x + 2 + jugador.direccion_x] == 1;
	// colision_3: para la celda (x+3;y)
	bool colision_3 = matriz[jugador.y][jugador.x + 2 + jugador.direccion_x] == 1;
	// colision_4: para la celda (x;y)
	bool colision_4 = matriz[jugador.y][jugador.x + 1 + jugador.direccion_x] == 1;

	// PARA MOVIMIENTO VERTICAL
	// colision_5: para la celda (x+1;y-1)
	bool colision_5 = matriz[jugador.y + jugador.direccion_y][jugador.x + 1] == 1;
	// colision_6: para la celda (x;y) || (x;y+2)
	bool colision_6 = matriz[jugador.y + 1 + jugador.direccion_y][jugador.x] == 1;
	// colision_7: para la celda (x+1;y+2)
	bool colision_7 = matriz[jugador.y + 1 + jugador.direccion_y][jugador.x + 1] == 1;
	// colision_8: para la celda (x+2;y+2)
	bool colision_8 = matriz[jugador.y + 1 + jugador.direccion_y][jugador.x + 2] == 1;
	// colision_9: para la celda (x+2;y-1)
	bool colision_9 = matriz[jugador.y + jugador.direccion_y][jugador.x + 2] == 1;

	if (colision_1 || colision_2 || colision_3 || colision_4 || colision_5 || colision_6 || colision_7 || colision_8 || colision_9) {
		return true;
	}
	return false;
}

void juego(int**& matriz, Ficha& jugador)
{
	dibujar_jugador(jugador);
	char tecla_presionada;
	while (true)
	{
		if (_kbhit()) {
			tecla_presionada = _getch();
			tecla_presionada = toupper(tecla_presionada);

			jugador.direccion_x = 0;
			jugador.direccion_y = 0;

			switch (tecla_presionada)
			{
			case 'W':
				jugador.direccion_y = -1;
				break;
			case 'S':
				jugador.direccion_y = 1;
				break;
			case 'A':
				jugador.direccion_x = -1;
				break;
			case 'D':
				jugador.direccion_x = 1;
				break;
			}

			if (!colisiona(matriz, jugador))
			{
				borrar_jugador(jugador);
				jugador.x += jugador.direccion_x;
				jugador.y += jugador.direccion_y;
				dibujar_jugador(jugador);
			}
		}
	}
}

int main()
{
	Console::CursorVisible = false;
	Ficha jugador;
	jugador.x = 10;
	jugador.y = 10;
	jugador.direccion_x = 0;
	jugador.direccion_y = 0;

	int** matriz;
	genera_muestra_matriz(matriz);
	juego(matriz, jugador);
	return 0;
}