#include <iostream>
#include <conio.h>

using namespace std;

void determinar_area_perimetro(float lado)
{
	cout << "Area: " << lado * lado << '\n';
	cout << "Perimetro: " << lado * 4 << '\n';

	--lado; // NO LO PONGAN
}

int main()
{
	float lado;
	do
	{
		cout << "Ingrese lado de cuadrado: ";
		cin >> lado;
	} while (!(lado > 0));

	cout << "Lado: " << lado << '\n'; // NO LO PONGAN
	determinar_area_perimetro(lado);
	cout << "Lado: " << lado << '\n'; // NO LO PONGAN
	_getch();
	return 0;
}