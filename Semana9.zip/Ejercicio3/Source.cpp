#include <iostream>
#include <conio.h>

using namespace std;

int fibonacci(int termino)
{
	int resultado = 0;
	int aux;
	int numero = 1;
	int anterior = 0;
	for (int i = 1; i <= termino; ++i)
	{
		aux = numero;
		resultado += numero;
		numero += anterior;
		anterior = aux;
	}
	return anterior;
}

void graficar(int numero)
{
	for (int fila = 1; fila <= numero; ++fila)
	{
		for (int columna = 1; columna <= numero; ++columna)
		{
			if (columna > numero - fila)
				cout << fibonacci(numero - (fila - 1));
			else
				cout << ' ';

			cout << '\t';
		}
		cout << '\n';
	}
}

int main()
{
	int numero;
	do
	{
		cout << "Ingrese el numero: ";
		cin >> numero;
	} while (!(numero >= 2 && numero <= 15));
	graficar(numero);
	_getch();
	return 0;
}