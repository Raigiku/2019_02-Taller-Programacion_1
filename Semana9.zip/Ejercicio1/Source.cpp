#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

long long factorial(int numero)
{
	long long resultado = numero;
	for (int i = numero - 1; i > 0; --i)
		resultado *= i;

	return resultado;
}

float serie(float y, int total_terminos)
{
	float resultado = 0;
	int contador = 0;
	int signo = 1;
	for (int i = 1; i <= total_terminos; ++i)
	{
		float numerador = (1 + contador) * pow(y, contador);
		float denominador = 1 + contador;
		resultado += (numerador / factorial(denominador))*signo;
		contador += 2;
		signo *= -1;
	}
	return resultado;
}

int cantidad_digitos_pares(int numero)
{
	int total_pares = 0;
	while (true)
	{
		int digito = numero % 10;
		if (digito % 2 == 0 && digito != 0)
			++total_pares;
		numero /= 10;
		if (numero <= 0)
			break;
	}
	return total_pares;
}

void menu()
{
	bool salir = false;
	do
	{
		cout << "1. Calcular la serie\n";
		cout << "2. Hallar cantidad de digitos pares\n";
		cout << "3. Fin\n";
		cout << "Ingrese opcion: ";
		int opcion;
		cin >> opcion;
		switch (opcion)
		{
		case 1:
			float y;
			do
			{
				cout << "Ingrese el valor de Y: ";
				cin >> y;
			} while (!(y >= 1.2 && y <= 3.6));

			int total_terminos;
			do
			{
				cout << "Ingrese el total de terminos: ";
				cin >> total_terminos;
			} while (!(total_terminos > 0));

			cout << "El valor de la serie es: " << serie(y, total_terminos) << '\n';
			_getch();
		case 2:
			int numero;
			do
			{
				cout << "Ingrese el numero: ";
				cin >> numero;
			} while (!(numero > 0));

			cout << "La cantidad de digitos par es: " << cantidad_digitos_pares(numero) << '\n';
			_getch();
			break;
		case 3:
			salir = true;
			break;
		default:
			break;
		}
		Console::Clear();
	} while (!salir);
}

int main()
{
	menu();
	return 0;
}