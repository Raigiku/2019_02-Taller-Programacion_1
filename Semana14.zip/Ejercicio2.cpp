#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

struct Empleado {
	int horas_asignadas;
	char facultad;
	int minutos_tardanza;
};

void genera_arreglo(Empleado* empleados, int total_empleados)
{
	Random r;
	for (int i = 0; i < total_empleados; ++i) {
		empleados[i].horas_asignadas = r.Next(4, 41);
		empleados[i].minutos_tardanza = r.Next(0, 251);

		int caracter_aleatorio_id = r.Next(1, 4);
		if (caracter_aleatorio_id == 1) {
			empleados[i].facultad = 'P';
		}
		else if (caracter_aleatorio_id == 2) {
			empleados[i].facultad = 'I';
		}
		else {
			empleados[i].facultad = 'A';
		}
	}
}

void imprime_arreglo(Empleado* empleados, int total_empleados)
{
	cout << "\tHoras\tFacultad\tMinutos\n";
	for (int i = 0; i < total_empleados; ++i) {
		cout << i << '\t'
			<< empleados[i].horas_asignadas << '\t'
			<< empleados[i].facultad << "\t\t"
			<< empleados[i].minutos_tardanza << '\n';
	}
}

void facultades_con_mas_tardanzas(Empleado* empleados, int total_empleados)
{
	int total_facultades = 3;
	int* min_tardanzas_por_facultad = new int[total_facultades];
	for (int i = 0; i < total_facultades; ++i) {
		min_tardanzas_por_facultad[i] = 0;
	}

	for (int i = 0; i < total_empleados; ++i) {
		switch (empleados[i].facultad)
		{
		case 'P':
			min_tardanzas_por_facultad[0] += empleados[i].minutos_tardanza;
			break;
		case 'I':
			min_tardanzas_por_facultad[1] += empleados[i].minutos_tardanza;
			break;
		case 'A':
			min_tardanzas_por_facultad[2] += empleados[i].minutos_tardanza;
			break;
		}
	}

	int mayor = min_tardanzas_por_facultad[0];
	for (int i = 1; i < total_facultades; ++i) {
		if (min_tardanzas_por_facultad[i] > mayor) {
			mayor = min_tardanzas_por_facultad[i];
		}
	}

	if (min_tardanzas_por_facultad[0] == mayor) {
		cout << "La facultad P tiene la mayor cantidad de minutos de tardanza: " << mayor << '\n';
	}
	if (min_tardanzas_por_facultad[1] == mayor) {
		cout << "La facultad I tiene la mayor cantidad de minutos de tardanza: " << mayor << '\n';
	}
	if (min_tardanzas_por_facultad[2] == mayor) {
		cout << "La facultad A tiene la mayor cantidad de minutos de tardanza: " << mayor << '\n';
	}

	delete[] min_tardanzas_por_facultad;
}

void promedio_de_horas_por_facultad(Empleado* empleados, int total_empleados)
{
	int total_facultades = 3;
	
	int* horas_por_facultad = new int[total_facultades];
	for (int i = 0; i < total_facultades; ++i) {
		horas_por_facultad[i] = 0;
	}
	
	int* cantidad_por_facultad = new int[total_facultades];
	for (int i = 0; i < total_facultades; ++i) {
		cantidad_por_facultad[i] = 0;
	}

	for (int i = 0; i < total_empleados; ++i) {
		switch (empleados[i].facultad)
		{
		case 'P':
			horas_por_facultad[0] += empleados[i].horas_asignadas;
			++cantidad_por_facultad[0];
			break;
		case 'I':
			horas_por_facultad[1] += empleados[i].horas_asignadas;
			++cantidad_por_facultad[1];
			break;
		case 'A':
			horas_por_facultad[2] += empleados[i].horas_asignadas;
			++cantidad_por_facultad[2];
			break;
		}
	}

	for (int i = 0; i < total_facultades; ++i) {
		int denominador = 1;
		if (cantidad_por_facultad[i] > 0) {
			denominador = cantidad_por_facultad[i];
		}

		char facultad;
		switch (i)
		{
		case 0:
			facultad = 'P';
			break;
		case 1:
			facultad = 'I';
			break;
		case 2:
			facultad = 'A';
			break;
		}

		cout << "Promedio de facultad " << facultad << ": " << horas_por_facultad[i] / denominador << '\n';
	}
}

void docentes_puntuales(Empleado* empleados, int total_empleados)
{
	for (int i = 0; i < total_empleados; ++i) {
		if (empleados[i].minutos_tardanza == 0) {
			cout << "Docente puntual: " << i << ' '
										<< empleados[i].horas_asignadas << ' '
										<< empleados[i].facultad << '\n';
		}
	}
}

void ordena_arreglo(Empleado* empleados, int total_empleados)
{
	for (int i = 0; i < total_empleados - 1; ++i) {
		for (int j = 0; j < total_empleados - 1 - i; ++j) {
			if (empleados[j + 1].facultad < empleados[j].facultad) {
				Empleado copia = empleados[j];
				empleados[j + 1] = empleados[j];
				empleados[j] = copia;
			}
		}
	}
}

int main()
{
	int total_empleados = 15;
	Empleado* empleados = new Empleado[total_empleados];

	genera_arreglo(empleados, total_empleados);
	ordena_arreglo(empleados, total_empleados);
	imprime_arreglo(empleados, total_empleados);
	facultades_con_mas_tardanzas(empleados, total_empleados);
	promedio_de_horas_por_facultad(empleados, total_empleados);
	docentes_puntuales(empleados, total_empleados);

	delete[] empleados;
	_getch();
	return 0;
}