#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void generar_mensaje(int* mensaje, int longitud_mensaje)
{
	Random r;
	for (int i = 0; i < longitud_mensaje; ++i) {
		mensaje[i] = r.Next(0, 10);
	}
}

void imprimir_mensaje(int* mensaje, int longitud_mensaje)
{
	for (int i = 0; i < longitud_mensaje; ++i) {
		cout << mensaje[i] << ' ';
	}
	cout << '\n';
}

bool existe_capicua(int* mensaje, int longitud_mensaje)
{
	bool es_capicua = mensaje[longitud_mensaje - 1] == mensaje[longitud_mensaje - 3];
	return es_capicua;
}

int main()
{
	Random r;
	int numeros_capicuas = 0;
	int i = 0;
	do
	{
		int longitud_mensaje = r.Next(10, 21);
		int* mensaje = new int[longitud_mensaje];
		
		cout << "Mensaje: " << i + 1 << "\n\n";
		generar_mensaje(mensaje, longitud_mensaje);
		imprimir_mensaje(mensaje, longitud_mensaje);
		cout << '\n';

		if (existe_capicua(mensaje, longitud_mensaje)) {
			cout << "         CONTACTO!!!\n";
			++numeros_capicuas;
		}
		delete[] mensaje;
		
		cout << "Presione una tecla para continuar...\n\n";
		_getch();
		++i;
	} while (!(numeros_capicuas >= 6));
	_getch();
	return 0;
}