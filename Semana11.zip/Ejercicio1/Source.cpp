#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void generar_y_mostrar_datos(int* puntajes, const int total_puntajes)
{
	Random r;
	for (int i = 0; i < total_puntajes; ++i) {
		puntajes[i] = r.Next(1, 5);
		cout << puntajes[i] << ' ';
	}
}

void lista_puntajes(int* puntajes, const int total_puntajes
					, int* cantidad_votos, const int puntaje_maximo)
{
	for (int i = 0; i < total_puntajes; ++i) {
		++cantidad_votos[puntajes[i] - 1];
	}
	cout << '\n';
	for (int i = 0; i < puntaje_maximo; ++i) {
		cout << "Puntaje:" << i+1 << " Votos:" << cantidad_votos[i] << '\n';
	}
}

void mayor_votacion(int* cantidad_votos, const int puntaje_maximo)
{
	int mayor = cantidad_votos[0];
	for (int i = 1; i < puntaje_maximo; ++i) {
		if (cantidad_votos[i] > mayor) {
			mayor = cantidad_votos[i];
		}
	}
	for (int i = 0; i < puntaje_maximo; ++i) {
		if (cantidad_votos[i] == mayor) {
			cout << "Mayor / voto:" << i + 1 << " cantidad:" << mayor << '\n';
		}
	}
}

int main()
{
	const int total_puntajes = 10;
	const int puntaje_maximo = 4;
	int* puntajes = new int[total_puntajes];
	int* cantidad_votos = new int[puntaje_maximo] {0,0,0,0};

	generar_y_mostrar_datos(puntajes, total_puntajes);
	lista_puntajes(puntajes, total_puntajes, cantidad_votos, puntaje_maximo);
	mayor_votacion(cantidad_votos, puntaje_maximo);
	_getch();
	return 0;
}