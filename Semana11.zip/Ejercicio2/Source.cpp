#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void generar(int* numeros, const int total_numeros)
{
	Random r;
	for (int i = 0; i < total_numeros; ++i) {
		numeros[i] = r.Next(0, 101);
	}
}

void mostrar(int* numeros, const int total_numeros)
{
	for (int i = 0; i < total_numeros; ++i) {
		cout << "Elemento:" << i << " Digito:" << numeros[i] << '\n';
	}
}

void cantidad_de_cada_digito(int* numeros, const int total_numeros)
{
	int* cantidad_digitos = new int[101];
	for (int i = 0; i < 101; ++i) {
		cantidad_digitos[i] = 0;
	}
	for (int i = 0; i < total_numeros; ++i) {
		++cantidad_digitos[numeros[i]];
	}
	for (int i = 0; i < 101; ++i) {
		cout << "Digito:" << i << " Cantidad:" << cantidad_digitos[i] << '\n';
	}
}

void cambiar_digito_primo(int* numeros, const int total_numeros)
{
	for (int i = 0; i < total_numeros; ++i) {
		bool primo = true;
		for (int j = 2; j < numeros[i]; ++j) {
			if (numeros[i] % j == 0) {
				primo = false;
			}
		}

		if (primo) {
			++numeros[i];
		}
	}
	mostrar(numeros, total_numeros);
}

int main()
{
	const int total_numeros = 5;
	int* numeros = new int[total_numeros];

	generar(numeros, total_numeros);
	mostrar(numeros, total_numeros);
	cout << '\n';
	cantidad_de_cada_digito(numeros, total_numeros);
	cambiar_digito_primo(numeros, total_numeros);
	_getch();
	return 0;
}