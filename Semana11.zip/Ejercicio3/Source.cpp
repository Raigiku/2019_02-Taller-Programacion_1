#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void generar(int* gramos, const int total_marcas)
{
	Random r;
	for (int i = 0; i < total_marcas; ++i) {
		gramos[i] = r.Next(32, 121);
		cout << "Marcas:" << i + 1 << " Gramos:" << gramos[i] << '\n';
	}
}

void marcas_sobrepasan(int* gramos, const int total_marcas)
{
	int sobrepasan = 0;
	for (int i = 0; i < total_marcas; ++i) {
		if (gramos[i] > 37) {
			++sobrepasan;
		}
	}
	cout << sobrepasan << " marcas sobrepasan el valor permitido\n";
}

void marcas_mayor_cantidad(int* gramos, const int total_marcas)
{
	int mayor = gramos[0];
	for (int i = 1; i < total_marcas; ++i) {
		if (gramos[i] > mayor) {
			mayor = gramos[i];
		}
	}
	for (int i = 0; i < total_marcas; ++i) {
		if (gramos[i] == mayor) {
			cout << "La Marca " << i + 1 << " tiene la mayor cantidad de azucar\n";
		}
	}
}

void marcas_cumplen(int* gramos, const int total_marcas)
{
	for (int i = 0; i < total_marcas; ++i) {
		if (gramos[i] <= 37) {
			cout << "La Marca " << i + 1 << ": cumple con la norma\n";
		}
	}
}

int main()
{
	const int total_marcas = 5;
	int* gramos = new int[total_marcas];
	generar(gramos, total_marcas);
	marcas_sobrepasan(gramos, total_marcas);
	cout << '\n';
	marcas_mayor_cantidad(gramos, total_marcas);
	cout << '\n';
	marcas_cumplen(gramos, total_marcas);
	_getch();
	return 0;
}