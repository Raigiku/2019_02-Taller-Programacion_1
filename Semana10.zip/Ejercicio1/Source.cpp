#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

float calculo_serie(int n)
{
	float resultado = 0;
	for (int i = 1; i <= n; ++i) {
		if (i % 2 == 0)
			resultado -= i / (2 * pow(i, 2) - 1);
		else
			resultado += i / (2 * pow(i, 2) - 1);
	}
	return resultado;
}

int cantidad_digitos_impar(int numero)
{
	int total_digitos_impares = 0;
	while (numero != 0) {
		int digito = numero % 10;
		if (digito % 2 != 0)
			++total_digitos_impares;

		numero /= 10;
	}
	return total_digitos_impares;
}

void menu()
{
	bool salir = false;
	do
	{
		cout << "Menu de opciones\n";
		cout << "1. Calcular la serie\n";
		cout << "2. Hallar cantidad de digitos impares\n";
		cout << "3. Fin\n";
		cout << "Ingrese opcion: ";
		int opcion;
		cin >> opcion;
		switch (opcion)
		{
		case 1:
			Console::Clear();
			int n;
			do
			{
				cout << "Ingrese el valor de N: ";
				cin >> n;
			} while (!(n > 0));
			cout << "El valor de la serie es: " << calculo_serie(n);
			_getch();
			break;
		case 2:
			Console::Clear();
			int numero;
			do
			{
				cout << "Ingrese el valor del numero: ";
				cin >> numero;
			} while (!(numero > 0));
			cout << "La cantidad de digitos es: " << cantidad_digitos_impar(numero);
			_getch();
			break;
		case 3:
			salir = true;
			break;
		}
		Console::Clear();
	} while (!(salir));
}

int main()
{
	menu();
	return 0;
}