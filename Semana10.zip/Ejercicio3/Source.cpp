#include <iostream>
#include <conio.h>

using namespace std;

void graficar1(int numero)
{
	int ancho_alto = numero * 2 - 1;
	for (int fila = 1; fila <= ancho_alto; ++fila) {
		for (int columna = 1; columna <= ancho_alto; ++columna) {
			if (columna == numero || fila == numero || columna == fila || columna == numero * 2 - fila)
				cout << numero;
			else
				cout << ' ';

			cout << ' ';
		}
		cout << '\n';
	}
}

void graficar2(int numero)
{
	int ancho_alto = numero * 2 - 1;
	for (int fila = 1; fila <= ancho_alto; ++fila) {
		for (int columna = 1; columna <= ancho_alto; ++columna) {
			if (columna == numero 
				|| fila == numero 
				|| columna == numero + 1 - fila
				|| columna == numero - 1 + fila
				|| columna == fila + 1 - numero
				|| columna == numero * 2 - 1 - (fila - numero))
					cout << numero;
			else
				cout << ' ';

			cout << ' ';
		}
		cout << '\n';
	}
}

int main()
{
	int numero;
	do
	{
		cout << "Ingrese el numero: ";
		cin >> numero;
	} while (!(numero >= 2 && numero <= 9));
	graficar1(numero);
	cout << '\n';
	graficar2(numero);
	_getch();
	return 0;
}