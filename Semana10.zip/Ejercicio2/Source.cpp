#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void area_volumen(float radio, float altura)
{
	float generatriz = sqrt(pow(radio, 2) + pow(altura, 2));
	float area_lateral = Math::PI * radio * generatriz;
	float area_total = area_lateral + Math::PI * pow(radio, 2);
	float volumen = (Math::PI * pow(radio, 2) * altura) / 3;
	cout << "El area total es: " << area_total << '\n';
	cout << "El volumen total es: " << volumen;
}

int main()
{
	float radio;
	do
	{
		cout << "Ingrese radio: ";
		cin >> radio;
	} while (!(radio > 0));
	float altura;
	do
	{
		cout << "Ingrese altura: ";
		cin >> altura;
	} while (!(altura > 0));
	area_volumen(radio, altura);
	_getch();
	return 0;
}