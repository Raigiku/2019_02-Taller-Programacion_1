#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	int total_transporte_a = 0;
	int total_transporte_t = 0;
	int total_transporte_p = 0;

	int total_viajes_1 = 0;
	int total_viajes_2 = 0;
	int total_viajes_3 = 0;
	int total_viajes_4 = 0;

	int total_duracion_ruta_a = 0;
	int total_duracion_ruta_b = 0;
	int total_duracion_ruta_c = 0;
	int total_duracion_ruta_o = 0;

	int total_ruta_a = 0;
	int total_ruta_b = 0;
	int total_ruta_c = 0;
	int total_ruta_o = 0;

	while (true)
	{
		char transporte;
		do
		{
			cout << "Medio de transporte: ";
			cin >> transporte;
			transporte = toupper(transporte);
			switch (transporte)
			{
			case 'A':
				++total_transporte_a;
				break;
			case 'T':
				++total_transporte_t;
				break;
			case 'P':
				++total_transporte_p;
				break;
			}
		} while (!(transporte == 'A' || transporte == 'T' || transporte == 'P' || transporte == 'X'));
		if (transporte == 'X')
			break;


		int duracion;
		do
		{
			cout << "Tiempo de duracion del viaje: ";
			cin >> duracion;
		} while (!(duracion > 0));

		int momento_dia;
		do
		{
			cout << "Momento del dia: ";
			cin >> momento_dia;
			switch (momento_dia)
			{
			case 1:
				++total_viajes_1;
				break;
			case 2:
				++total_viajes_2;
				break;
			case 3:
				++total_viajes_3;
				break;
			case 4:
				++total_viajes_4;
				break;
			}
		} while (!(momento_dia >= 1 && momento_dia <= 4));

		char ruta;
		do
		{
			cout << "Ruta elegida: ";
			cin >> ruta;
			ruta = toupper(ruta);
			switch (ruta)
			{
			case 'A':
				total_duracion_ruta_a += duracion;
				++total_ruta_a;
				break;
			case 'B':
				total_duracion_ruta_b += duracion;
				++total_ruta_b;
				break;
			case 'C':
				total_duracion_ruta_c += duracion;
				++total_ruta_c;
				break;
			case 'O':
				total_duracion_ruta_o += duracion;
				++total_ruta_o;
				break;
			}
		} while (!((ruta >= 'A' && ruta <= 'C') || ruta == 'O'));
		cout << '\n';
	}

	cout << "Reporte\n";
	cout << "Cantidad de usuarios por medio de transporte\n";
	cout << "Auto propio: " << total_transporte_a << '\n';
	cout << "Privado: " << total_transporte_p << '\n';
	cout << "Transporte publico: " << total_transporte_t << '\n';

	int mayor = total_viajes_1;
	if (total_viajes_2 > mayor)
		mayor = total_viajes_2;
	if (total_viajes_3 > mayor)
		mayor = total_viajes_3;
	if (total_viajes_4 > mayor)
		mayor = total_viajes_4;

	cout << "Momentos con mayor cantidad de viajes son: ";
	if (total_viajes_1 == mayor)
		cout << "1 ";
	if (total_viajes_2 == mayor)
		cout << "2 ";
	if (total_viajes_3 == mayor)
		cout << "3 ";
	if (total_viajes_4 == mayor)
		cout << "4 ";
	cout << '\n';

	cout << "Tiempo promedio de viaje por ruta son:\n";

	float tiempo_promedio = 0;
	if (total_ruta_a > 0)
		tiempo_promedio = total_duracion_ruta_a / float(total_ruta_a);
	cout << "Av. Arequipa: " << tiempo_promedio << '\n';

	tiempo_promedio = 0;
	if (total_ruta_b > 0)
		tiempo_promedio = total_duracion_ruta_b / float(total_ruta_b);
	cout << "Av. Brasil: " << tiempo_promedio << '\n';

	tiempo_promedio = 0;
	if (total_ruta_c > 0)
		tiempo_promedio = total_duracion_ruta_c / float(total_ruta_c);
	cout << "Paseo de la Rep�blica: " << tiempo_promedio << '\n';

	tiempo_promedio = 0;
	if (total_ruta_o > 0)
		tiempo_promedio = total_duracion_ruta_o / float(total_ruta_o);
	cout << "Otra ruta: " << tiempo_promedio << '\n';

	_getch();
	return 0;
}

