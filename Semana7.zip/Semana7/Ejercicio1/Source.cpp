#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	int n;
	do
	{
		cout << "Ingrese el valor de N: ";
		cin >> n;
	} while (!(n > 0 && n < 120));

	double e = 0;
	for (int i = 1; i <= n; ++i)
	{
		double factorial = 1;
		for (int j = 1; j <= i; ++j)
		{
			factorial *= j;
		}
		e += pow(i, 2) / (2 * factorial);
	}
	cout << "El valor del numero e es: " << e;

	_getch();
	return 0;
}