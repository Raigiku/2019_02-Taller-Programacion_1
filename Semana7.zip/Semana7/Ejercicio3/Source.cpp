#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	// Comprobar el ingreso de datos
	int n = 6;
	// Comprobar el ingreso de datos


	char caracter_especial = '_';
	for (int fila = 1; fila <= 6; ++fila)
	{
		if (fila % 2 == 0)
			caracter_especial = char(179);
		else
			caracter_especial = char(196);

		for (int j = 1; j <= n - fila; ++j)
			cout << ' ';

		int limite_carateres = fila * 2 - 1;
		for (int j = 1; j <= limite_carateres; ++j)
		{
			if (j == 1 || j == limite_carateres)
				cout << caracter_especial;
			else
				cout << char(250);
		}
		cout << '\n';
	}

	_getch();
	return 0;
}